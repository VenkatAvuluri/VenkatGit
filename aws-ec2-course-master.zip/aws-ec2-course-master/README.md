# AWS EC2 MUST KNOW 20 Facts and 10 MUST DO Labs
This is the repo for our course on Udemy. [Click here](https://www.udemy.com/cloudyeti-ec2) to buy the course. 


## Course Slides
[Click here](https://github.com/Cloud-Yeti/aws-ec2-course/blob/master/20%20MUST%20KNOW%20things%20about%20Amazon%20EC2.pdf)

## Questions
If you have any questions please ask them [here](https://github.com/Cloud-Yeti/aws-ec2-course/issues/new) by opening an issue. 

## Contact Us
contact@cloudyeti.io
